function Property(){
	
	
}

Property.fontAwsmClass = {
			  "checked":"fa-check-square-o",
			  "unChecked":"fa-square-o"
			};

